﻿public interface ISorter<T>
{
    void Sort();
}