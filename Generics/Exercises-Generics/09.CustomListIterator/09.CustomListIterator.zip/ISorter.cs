﻿public interface ISorter
{
    void Sort();
}

