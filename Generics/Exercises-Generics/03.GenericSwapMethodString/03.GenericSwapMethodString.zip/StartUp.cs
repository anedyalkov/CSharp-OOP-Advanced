﻿using System;

namespace _03.GenericSwapMethodString
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var count = int.Parse(Console.ReadLine());

            var box = new Box<string>();

            for (int i = 0; i < count; i++)
            {
                var input = Console.ReadLine();
                box.Add(input);
                //Console.WriteLine(box);
            }

            var swapCommand = Console.ReadLine().Split();

            var firstIndex = int.Parse(swapCommand[0]);
            var secondIndex = int.Parse(swapCommand[1]);

            box.Swap(firstIndex, secondIndex);

            Console.WriteLine(box);
        }
    }
}
