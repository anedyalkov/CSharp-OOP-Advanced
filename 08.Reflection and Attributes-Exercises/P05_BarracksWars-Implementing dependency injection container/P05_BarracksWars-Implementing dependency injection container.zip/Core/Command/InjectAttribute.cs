﻿namespace P03_BarraksWars.Core.Command
{
    using System;

    public class InjectAttribute : Attribute
    {
    }
}
