namespace CosmosX.Tests
{
    //using CosmosX.Entities.Containers;
    //using CosmosX.Entities.Modules.Absorbing;
    //using CosmosX.Entities.Modules.Energy;
    //using CosmosX.Entities.Reactors;
    using NUnit.Framework;

    [TestFixture]
    public class ModuleContainerTests
    {
        [Test]
        public void TestToCreateEnergyModule()
        {
            //            Reactor Cryo 10 10
            //Reactor Cryo 2 15
            //Module 1 CryogenRod 100

            var moduleContainer = new ModuleContainer(10);

            //var reactor = new CryoReactor(1,moduleContainer, 2);
            var module = new CryogenRod(1, 100);
            moduleContainer.AddEnergyModule(module);
            //reactor.AddEnergyModule(module);
            System.Console.WriteLine(moduleContainer.TotalEnergyOutput);
            System.Console.WriteLine(moduleContainer.TotalHeatAbsorbing);
            Assert.That(moduleContainer.TotalEnergyOutput, Is.EqualTo(100));

        }

        [Test]
        public void TestToCreateAbsorbingModule()
        {
            
            var moduleContainer = new ModuleContainer(4);

            //var reactor = new CryoReactor(1,moduleContainer, 2);
            var module = new HeatProcessor(1, 200);
            moduleContainer.AddAbsorbingModule(module);
            //reactor.AddEnergyModule(module);
            //System.Console.WriteLine(moduleContainer.TotalEnergyOutput);
            System.Console.WriteLine(moduleContainer.TotalHeatAbsorbing);
            Assert.That(moduleContainer.TotalHeatAbsorbing, Is.EqualTo(200));

        }

        [Test]
        public void TestToRemoveOldestModule()
        {

            var moduleContainer = new ModuleContainer(1);

            //var reactor = new CryoReactor(1,moduleContainer, 2);
            var module1 = new HeatProcessor(1, 200);
            var module2 = new HeatProcessor(2, 300);
            moduleContainer.AddAbsorbingModule(module1);
            moduleContainer.AddAbsorbingModule(module2);

            System.Console.WriteLine(moduleContainer.TotalHeatAbsorbing);
            Assert.That(moduleContainer.ModulesByInput.Count, Is.EqualTo(1));

        }
    }
}