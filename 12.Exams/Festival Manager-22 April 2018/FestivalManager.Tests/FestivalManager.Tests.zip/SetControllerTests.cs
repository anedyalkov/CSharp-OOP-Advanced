// Use this file for your unit tests.
// When you are ready to submit, REMOVE all using statements to your project (entities/controllers/etc)
namespace FestivalManager.Tests
{
    //using FestivalManager.Core.Controllers;
    //using FestivalManager.Entities;
    //using FestivalManager.Entities.Instruments;
    //using FestivalManager.Entities.Sets;
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class SetControllerTests
    {
        //[Test]
        //public void TestControllerDidNotPerformSet()
        //{
        //    var set1 = new Short("set1");
        //    var performer = new Performer("Danny", 39);
        //    var instrument = new Guitar();
        //    performer.AddInstrument(instrument);
        //    var song = new Song("name", new TimeSpan(0, 0, 15, 0));

        //    var stage = new Stage();
        //    stage.AddSet(set1);
        //    stage.AddPerformer(performer);
        //    stage.AddSong(song);

        //    var controller = new SetController(stage);
        //    var expected = "1. set1:" + Environment.NewLine + "-- Did not perform";

        //    Assert.AreEqual(expected, controller.PerformSets());

        //}


        //[Test]
        //public void TestControllerPerformSetAndPrintSong()
        //{
        //    var set1 = new Short("set1");
        //    var performer = new Performer("Danny", 39);
        //    set1.AddPerformer(performer);
        //    var instrument = new Guitar();
        //    performer.AddInstrument(instrument);
        //    var song = new Song("name", new TimeSpan(0, 0, 15, 0));
        //    set1.AddSong(song);

        //    var stage = new Stage();
        //    stage.AddSet(set1);

        //    var controller = new SetController(stage);
        //    var expected = "1. set1:" + Environment.NewLine + "-- 1. name (15:00)" + Environment.NewLine + "-- Set Successful";

        //    Assert.AreEqual(expected, controller.PerformSets());

        //}

        //[Test]
        //public void TestControllerPerformSetAndWearDownInstrument()
        //{
        //    var set1 = new Short("set1");
        //    var performer = new Performer("Danny", 39);
        //    set1.AddPerformer(performer);
        //    var instrument = new Guitar();
        //    performer.AddInstrument(instrument);
        //    var song = new Song("name", new TimeSpan(0, 0, 15, 0));
        //    set1.AddSong(song);

        //    var stage = new Stage();
        //    stage.AddSet(set1);
        //    var controller = new SetController(stage);
        //    controller.PerformSets();

        //    Assert.That(instrument.Wear, Is.EqualTo(40));

        //}

        //[Test]
        //public void TestControllerDidNotPerformSetWithBrokenInstruments()
        //{
        //    var set1 = new Short("set1");
        //    var performer = new Performer("Danny", 38);
        //    var instrument = new Microphone();
        //    performer.AddInstrument(instrument);
        //    var song = new Song("name", new TimeSpan(0, 0, 5, 0));

        //    var stage = new Stage();
        //    set1.AddPerformer(performer);
        //    set1.AddSong(song);
        //    stage.AddSet(set1);
        //    stage.AddPerformer(performer);
        //    stage.AddSong(song);

        //    var controller = new SetController(stage);
        //    controller.PerformSets();
        //    controller.PerformSets();
        //    var stringOutput = controller.PerformSets();
        //    var expected = "1. set1:" + Environment.NewLine + "-- Did not perform";

        //    Assert.AreEqual(expected, stringOutput);

        //}

        [Test]
        public void Test1()
        {
            var set = new Medium("Set2");
            var performer = new Performer("Pesho", 20);
            var instrument = new Guitar();
            performer.AddInstrument(instrument);
            set.AddPerformer(performer);
            var stage = new Stage();
            stage.AddSet(set);
            var setController = new SetController(stage);

            var expectedResult = "1. Set2:\r\n-- Did not perform";
            var actualresult = setController.PerformSets();
            //Console.WriteLine();
            Assert.That(actualresult, Is.EqualTo(expectedResult));
        }

        [Test]
        public void Test2()
        {
            var set = new Medium("Set2");
            var performer = new Performer("Pesho", 20);
            var instrument = new Guitar();
            performer.AddInstrument(instrument);
            set.AddPerformer(performer);
            var song = new Song("pipi", new TimeSpan(0, 15, 0));
            var stage = new Stage();
            var setController = new SetController(stage);
            set.AddSong(song);
            stage.AddSet(set);


            var expectedResult = "1. Set2:\r\n-- 1. pipi (15:00)\r\n-- Set Successful";
            var actualresult = setController.PerformSets();
            Console.WriteLine();
            Assert.That(actualresult, Is.EqualTo(expectedResult));
        }
    }
}