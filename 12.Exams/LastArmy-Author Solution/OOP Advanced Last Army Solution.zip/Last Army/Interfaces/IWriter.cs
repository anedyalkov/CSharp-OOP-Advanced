﻿public interface IWriter
{
    void AppendLine(string line);
    void WriteLineAll();
}