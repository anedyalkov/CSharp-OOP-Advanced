﻿namespace TheTankGame.Tests
{
    using NUnit.Framework;

    [TestFixture]
    public class BaseVehicleTests
    {
    }
}