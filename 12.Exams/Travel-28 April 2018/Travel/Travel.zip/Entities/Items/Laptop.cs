﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Travel.Entities.Items
{
    public class Laptop : Item
    {
        public Laptop() 
            : base(value: 3000)
        {
        }
    }
}
