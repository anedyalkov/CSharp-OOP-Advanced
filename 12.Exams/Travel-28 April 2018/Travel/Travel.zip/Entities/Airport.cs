﻿namespace Travel.Entities
{
	using System;
	using System.Collections.Generic;
	using System.Linq;

	using Contracts;
	
	public class Airport : IAirport
	{
		private List<IBag> takenBags;
		private List<IBag> notTakenBags;
		private List<ITrip> adventures;
		private List<IPassenger> people;

        public Airport()
        {
            takenBags = new List<IBag>();
            notTakenBags = new List<IBag>();
            adventures = new List<ITrip>();
            people = new List<IPassenger>();
        }

        public IReadOnlyCollection<IBag> CheckedInBags => notTakenBags.AsReadOnly();

        public IReadOnlyCollection<IBag> ConfiscatedBags => takenBags.AsReadOnly();

        public IReadOnlyCollection<IPassenger> Passengers => people.AsReadOnly();

        public IReadOnlyCollection<ITrip> Trips => adventures.AsReadOnly();

        public IPassenger GetPassenger(string username) => people.FirstOrDefault(p => p.Username == username);

		public ITrip GetTrip(string id) => adventures.FirstOrDefault(t => t.Id == id);

        public void AddPassenger(IPassenger passenger) => people.Add(passenger);

        public void AddTrip(ITrip trip) => adventures.Add(trip);

        public void AddCheckedBag(IBag bag) => notTakenBags.Add(bag);

        public void AddConfiscatedBag(IBag bag) => takenBags.Add(bag);
	}
}