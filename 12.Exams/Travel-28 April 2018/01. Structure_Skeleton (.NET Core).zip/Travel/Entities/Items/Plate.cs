﻿namespace Travel.Entities.Items
{
	public class Plate : Item
	{
		public Plate()
			: base(1)
		{
		}
	}
}