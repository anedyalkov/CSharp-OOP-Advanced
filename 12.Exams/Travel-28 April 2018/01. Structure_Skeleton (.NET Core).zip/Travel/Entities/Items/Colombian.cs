﻿namespace Travel.Entities.Items
{
	public class Colombian : Item
	{
		public Colombian()
			: base(value: 50000)
		{
		}
	}
}