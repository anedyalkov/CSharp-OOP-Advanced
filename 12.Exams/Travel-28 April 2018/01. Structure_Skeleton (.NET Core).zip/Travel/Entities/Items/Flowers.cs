﻿namespace Travel.Entities.Items
{
	public class Flowers : Item
	{
		public Flowers()
			: base(3)
		{
		}
	}
}