﻿namespace Travel.Entities.Items
{
	public class Screwdriver : Item
	{
		public Screwdriver()
			: base(5)
		{
		}
	}
}