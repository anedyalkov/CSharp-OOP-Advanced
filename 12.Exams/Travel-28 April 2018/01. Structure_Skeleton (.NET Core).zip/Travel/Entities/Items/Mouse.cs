﻿namespace Travel.Entities.Items
{
	public class Mouse : Item
	{
		public Mouse()
			: base(10)
		{
		}
	}
}