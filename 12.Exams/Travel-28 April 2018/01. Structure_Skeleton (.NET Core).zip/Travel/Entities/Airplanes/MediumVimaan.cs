﻿namespace Travel.Entities.Airplanes
{
	public class MediumVimaan : Vimaan
	{
		public MediumVimaan()
			: base(mesta: 10, chanti: 14)
		{
		}
	}
}