﻿namespace _01.ListyIterator
{
    using _01.ListyIterator.Contracts;
    using System;
    using System.Linq;

    public class Engine :IEngine
    {
        private bool isRunning;
        ICommandInterpreter commandInterpreter;

        public Engine(ICommandInterpreter commandInterpreter)
        {
            this.commandInterpreter = commandInterpreter;
            isRunning = true;
        }
        public void Run()
        {
            while (isRunning)
            {
                var input = Console.ReadLine();
                if (input == "END")
                {
                    isRunning = false;
                    break;
                }
                //var inputArgs = input.Split(" ").ToArray();
                //var command = inputArgs[0];
                //var commandArgs = inputArgs.Skip(1).ToArray();

                try
                {
                    commandInterpreter.ParseCommand(input);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
