﻿namespace _01.ListyIterator.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
