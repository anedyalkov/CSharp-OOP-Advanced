﻿namespace _01.ListyIterator.Contracts
{
    public interface ICommandInterpreter
    {
        void ParseCommand(string input);
    }
}
