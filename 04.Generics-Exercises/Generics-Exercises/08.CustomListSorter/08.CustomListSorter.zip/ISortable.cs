﻿namespace _08.CustomListSorter
{
    public interface ISortable
    {
        void Sort();
    }
}
