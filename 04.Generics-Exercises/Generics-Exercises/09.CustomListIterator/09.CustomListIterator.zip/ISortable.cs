﻿namespace _09.CustomListIterator
{
    public interface ISortable
    {
        void Sort();
    }
}
