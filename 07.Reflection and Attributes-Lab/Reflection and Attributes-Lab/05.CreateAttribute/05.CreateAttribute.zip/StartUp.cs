﻿using System;
[SoftUni("Me")]
public class StartUp
{
    [SoftUni("Pesho")]
    public static void Main()
    {
        
    }
}

