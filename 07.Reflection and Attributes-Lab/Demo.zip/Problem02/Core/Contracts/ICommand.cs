﻿namespace Problem02.Core.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}
