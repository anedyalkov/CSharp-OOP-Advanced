﻿namespace Problem02.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
