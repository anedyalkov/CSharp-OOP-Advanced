﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem05.Animal
{
    public class Lion : Animal
    {
        public Lion(string name, int age) 
            : base(name, age)
        {
            
        }
    }
}
