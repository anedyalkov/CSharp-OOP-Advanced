﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem05.Animal
{
    public class Mammal
    {
        public string Name { get; set; }
    }
}
