﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem05.Animal
{
    public class Tiger : Animal
    {
        public Tiger(string name, int age)
            : base(name, age)
        {
        }
    }
}
