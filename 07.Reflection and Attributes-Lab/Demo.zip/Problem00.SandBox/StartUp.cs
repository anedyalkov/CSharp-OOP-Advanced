﻿using System;
using System.IO;

namespace Problem00.SandBox
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
